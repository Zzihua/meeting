import React from 'react';
import './home.css';


const Home = () => {
  return (
    <div className="home">
      <div className='background'>
        <h1>會議管理系統</h1>
      </div>
      
    </div>
  );
};

export default Home;
