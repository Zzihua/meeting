import {useState, useRef , useCallback, useEffect} from 'react';
import { AgGridReact} from 'ag-grid-react';//記得install
import { Button } from 'semantic-ui-react';
import './Meeting.css';
import 'ag-grid-community/styles/ag-grid.css'
import 'ag-grid-community/styles/ag-theme-alpine.css'
import wrenchicon from '../../image/wrench.png'
import binicon from '../../image/bin.png'
import calendaricon from '../../image/calendar.png'


//查詢
const Meeting = () => {
  // const [searchKeyword, setSearchKeyword] = useState('');
  // const [selectedDate, setSelectedDate] = useState('');

  // 查詢，使用 searchKeyword 和 selectedDate 進行篩選
  const handleSearch = () => {
  };

//表格
  const gridRef = useRef();
  const [gridApi, setGridApi] = useState(null);
  const [rowData,setRowData] = useState(null) ;
  const url = ' http://localhost:4000/meetings';
  

 

  const [columnDefs,setColumnDefs] = useState([ //sortable:排序//filter:過濾器//editable:可編輯的
    {headerName:'會議ID', field:'meetingid',filter:true,sortable:true,checkboxSelection:true},
    {headerName:'會議名稱',field:'meetingname',filter:true,sortable:true},
    {headerName:'日期',field:'date',filter:'agDateColumnFilter',sortable:true},
    {headerName:'開始時間',field:'starttime',filter:true,sortable:true},
    {headerName:'結束時間',field:'endtime',filter:true,sortable:true},
    {headerName:'地點',field:'place',filter:true},
    {headerName:'簽到簽退',field:'signinout',cellRenderer:(params) => (
      <div>
        <Button className="look-button" onClick={() => handleLook (params.data.meetingname)}><img src={calendaricon} className="calendaricon" alt="calendaricon"/></Button>
      </div>
      )},
    {headerName:'操作',field:'meetingid',cellRenderer:(params) => (
    <div>
      <Button className="delete-button" onClick={() => handleDeleteClick (params.data.meetingid)}><img src={binicon} className="binicon" alt="binicon"/></Button> 
      <Button className="edit-button" onClick={() => handleEditClick (params.data.meetingid)}><img src={wrenchicon} className="wrenchicon" alt="wrenchicon"/></Button>
    </div>
    )}
  ]);
  //對格子統一調整
  const defaultColDef = {
    flex:1
  }
  const onGridReady = (params) => {
    setGridApi(params)
  }

  //回傳選取資料
  const cellClickedListener = useCallback( event => {
    console.log('cellClicked', event);
  });
  const getRowId = useCallback( params => {
    return params.data.meetingid;
  });

  useEffect(()=>{
    getMeetings()
  },[])
  const getMeetings = () => {
    fetch(url)
      .then(resp => resp.json())
      .then(resp => {
        console.log(resp); 
        setRowData(resp);
      })
      .catch(error => {
        console.error('Error fetching meetings:', error);
      });    
  }

  //------------------------------------------------------------------------------
  const handleLook=(params)=>{
    // 查看按鈕事件
    console.log("查看簽到簽退",params);
  };
  
  //刪除
  
  const handleDeleteClick = (meetingid) => {
    const deleteUrl = `${url}/${encodeURIComponent(meetingid)}`;
  
    const confirm = window.confirm(`您確定要刪除這個會議嗎?`);
    if (confirm) {
      fetch(deleteUrl, { method: "DELETE" })
        .then(resp => resp.json())
        .then(resp => {
          console.log("Delete Response:", resp);
          getMeetings();
        })
        .catch(error => {
          console.error("Error deleting meeting:", error);
        });
    }
  };
  
  
  
  
  
  //編輯
  const handleEditClick = (meetingid) => {
    // fetch(url+`/${meetingid}`,{method:"UPDATE"}).then(resp => resp.json()).then(resp => getMeetings())
  };
  //----------------------------------------------------------------------------- 

//   // 表格适应页面大小
//   function onTotalGridReady(params) {
//     gridOptions.api.sizeColumnsToFit();//调整表格大小自适应
// }


  return (
    <div>
      <h2>會議清單</h2>
      <div className='search'>
        <input
          type="text"
          placeholder="...搜尋"
          // value={searchKeyword}
          // onChange={(e) => setSearchKeyword(e.target.value)}
        />
        <input
          type='date'
          // value={selectedDate}
          // onChange={(e) => setSelectedDate(e.target.value)}
        />
        <button onClick={handleSearch}>查詢</button>
      </div>
      <ul>
        {/* {meetings.map(meeting => (<MeetingItem key={meeting.id} meeting={meeting} />))} */}
      </ul>
      <div className='ag-theme-alpine' style={{height:500}}>			
        <AgGridReact ref={gridRef}
          rowData={rowData}
          columnDefs={columnDefs}
          defaultColDef={defaultColDef}
          onGridReady={onGridReady}
          rowSelection='multiple'//同時選擇多行
          onCellClicked={cellClickedListener}
          getRowId={getRowId}
          domLayout='autoHeight'
          >
        </AgGridReact>
      </div>
      <div className="button-container">
      </div>

    </div>
  );
};


export default Meeting;
