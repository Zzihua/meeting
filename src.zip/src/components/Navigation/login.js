import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './login.css'; // 導入CSS

const Login = () => {
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [employeeId, setEmployeeId] = useState('');
  const [password, setPassword] = useState('');
  const [Password2, setPassword2] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    // 簡單的登入邏輯，要視實際情況
    console.log('Submitted:', { name, username, employeeId, password, Password2 });
  };
  
  return (
    <div className="login-container">
      <h2>註冊資料</h2>
      <form className="form-container" onSubmit={handleSubmit}>
        <div className='row'>
          <div>
            <label><b>姓名</b></label><br></br>
            <input type="text" value={name} onChange={(e) => setName(e.target.value)} />
          </div>
          <div>
            <label><b>密碼</b></label><br></br>
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
          </div>
        </div>

        <div className='row'>
          <div>
            <label><b>帳號</b></label><br></br>
            <input type="text" value={username} onChange={(e) => setUsername(e.target.value)} />
          </div>
          <div>
            <label><b>確認密碼</b></label><br></br>
            <input type="password" value={Password2} onChange={(e) => setPassword2(e.target.value)} />
          </div>
        </div>
        
        <div className='row'>
          <div>
            <label><b>員工編號</b></label><br></br>
            <input type="text" value={employeeId} onChange={(e) => setEmployeeId(e.target.value)} />
          </div>
        </div>
        
        <div className='buttons'>
          <button type="submit" ><b>送出</b></button>
          <button type="login" ><Link to="/Home"><b>登入</b></Link></button>
          {/* <button><Link to="/Home"><b>登入</b></Link></button> */}
        </div>
        
      </form>
    </div>
  );
};

export default Login;

