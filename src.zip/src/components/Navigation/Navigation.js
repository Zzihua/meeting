import React from 'react';
import './Navigation.css';
import usericon from '../../image/usericon.png'
import { Link } from 'react-router-dom';

const Navigation = () => {
  return (
    <nav className="navigation">
      <ul>
        <li><Link to="/"><b>HOME</b></Link></li>
        <li className="submenu">
          <b className="underline"><u>會議管理</u></b>
          <ul className="dropdown-menu">
            <li><Link to="/建立會議">建立會議</Link></li>
            <li><Link to="/會議清單">會議清單</Link></li>
          </ul>
        </li>
        <li><Link to="/會議室"><b><u>會議室</u></b></Link></li>
        <li><Link to="/人員管理"><b><u>人員管理</u></b></Link></li>
        <li className="login"><Link to="/login">login</Link></li>
        <li><a href="/user"><img src={usericon} className="usericon" alt="usericon"/></a></li>
      </ul>
    </nav>
  );
};

export default Navigation;

