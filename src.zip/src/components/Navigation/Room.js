import React from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import './Room.css';
import { BsWindowStack } from "react-icons/bs";


const OperateCellRenderer = (params) => {
  const handleLook = () => {
    // 查看按鈕事件
    console.log('查看', params.data);
  };
  return (
    <div className="button-container">
      <button className="look2-button" onClick={() => handleLook (params.meetingid)}><BsWindowStack/></button>
    </div>
  );
};

const MeetingRoom = () => {
  const handleSearch = () => {
  };

  const columnDefs = [
    { headerName: '編號', field: 'id', filter: true, sortable: true, checkboxSelection: true },
    { headerName: '會議名稱', field: 'name', filter: true, sortable: true },
    { headerName: '地點', field: 'where', filter: true, sortable: true },
    { headerName: '操作', field: 'operate' , cellRenderer: OperateCellRenderer}
  ];
  
  const frameworkComponents = {
    operateCellRenderer: OperateCellRenderer,
  };
  



  const rowData = [
    { id: '1', name: '銷售組開會', where: 'A101' },
    { id: '2', name: '企劃組開會', where: 'A102' },
  ];
    return (
      <div className="center-container">
        <h2>會議室</h2>
        <div className="search-and-table">
          <div className="search">
            <input
              type="text"
              placeholder="...搜尋"
              // value={searchTerm}
              // onChange={(e) => setSearchTerm(e.target.value)}
            />
            <button onClick={handleSearch}>查詢</button>
          </div>
          <div className="ag-theme-alpine center-table" style={{height:500 ,width:'770px'}}>
            <AgGridReact
              rowData={rowData}
              columnDefs={columnDefs}
              rowSelection='multiple'//同時選擇多行
              animateRows={true} //整行式變動
              frameworkComponents={frameworkComponents}
              // onCellClicked={cellClickedListener}
              
            />
          </div>
        </div>
      </div>
    );
  };
  
export default MeetingRoom;