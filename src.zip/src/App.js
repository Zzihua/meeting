// // import logo from './logo.svg';
// import './App.css';

// function App() {
//   return (
//     <div className="App">
//       <header className="App-header">
//         {/* <img src={logo} className="App-logo" alt="logo" /> */}
//         {/* <p> */}
//           {/* Edit <code>src/App.js</code> and save to reload. */}
//         {/* </p> */}
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
          
//         </a>
//       </header>
//     </div>
//   );
// }

// export default App;
// --------------------------------------------------------------------------------------
// import React, { useState } from 'react';
// import MeetingList from './components/MeetingList';
// import CreateMeetingForm from './components/CreateMeetingForm';

// const App = () => {
//   const [meetings, setMeetings] = useState([]);

//   const addMeeting = (meeting) => {
//     setMeetings([...meetings, meeting]);
//   };

//   const deleteMeeting = (id) => {
//     setMeetings(meetings.filter((meeting) => meeting.id !== id));
//   };

//   return (
//     <div>
//       <h1>Meeting Manager</h1>
//       <CreateMeetingForm addMeeting={addMeeting} />
//       <MeetingList meetings={meetings} deleteMeeting={deleteMeeting} />
//     </div>
//   );
// };

// export default App;

import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Home from './components/Navigation/home';
import Login from './components/Navigation/login';
import Meeting from './components/Navigation/Meeting';
import Createmeeting from './components/Navigation/createmeeting'
import MeetingRoom from './components/Navigation/Room';
import People from './components/Navigation/People';
import Navigation from './components/Navigation/Navigation';
// import Roomdeatails from './components/Navigation/Roomdeatails'


const App = () => {
  return (
    <Router>
      <Navigation />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/建立會議" element={<Createmeeting />} />
        <Route path="/會議清單" element={<Meeting />} />
        <Route path="/會議室" element={<MeetingRoom />} />
        <Route path="/人員管理" element={<People />} /> 
      </Routes>
    </Router>
  );
};

export default App;





